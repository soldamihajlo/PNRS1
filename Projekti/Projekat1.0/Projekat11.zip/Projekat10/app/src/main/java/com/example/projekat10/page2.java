package com.example.projekat10;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class page2 extends AppCompatActivity {
    TextView twoPageTextView2;
    TextView twoPageTextView4;
    Spinner twoPageSppiner;
    String strDay="";
    String[] strSppnr;
    ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page2);

        Calendar cal=Calendar.getInstance();
        int day=cal.get(Calendar.DAY_OF_WEEK);


        switch (day){
            case Calendar.MONDAY:
                strDay="Ponedeljak";
                break;

            case Calendar.TUESDAY:
                strDay="Utorak";
                break;

            case Calendar.WEDNESDAY:
                strDay="Sreda";
                break;

            case Calendar.THURSDAY:
                strDay="Cetvrtak";
                break;

            case Calendar.FRIDAY:
                strDay="Petak";
                break;

            case Calendar.SATURDAY:
                strDay="Subota";
                break;

            case Calendar.SUNDAY:
                strDay="Nedelja";
                break;

        }

        twoPageTextView2=(TextView) findViewById(R.id.pageTwoTextView2);
        twoPageTextView4=(TextView) findViewById(R.id.pageTwoTextView4);
        twoPageTextView2.setText(getIntent().getStringExtra("text1"));
        twoPageTextView4.setText(strDay);
        twoPageSppiner=findViewById(R.id.pageTwoSpinner);
        strSppnr=new String[]{"C","F"};
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, strSppnr);

        twoPageSppiner.setAdapter(adapter);

    }


}
