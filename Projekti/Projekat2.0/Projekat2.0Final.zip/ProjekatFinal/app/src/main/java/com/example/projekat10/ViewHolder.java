package com.example.projekat10;

import android.widget.RadioButton;
import android.widget.TextView;

class ViewHolder {
    public RadioButton button=null;
    public TextView name=null;
}
